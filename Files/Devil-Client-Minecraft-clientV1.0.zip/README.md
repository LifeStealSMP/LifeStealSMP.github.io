# Devil Client Beta
MC pvp client for 1.8.9

# Patch Notes
V1.1 Features-
          1.Custom Devil cape for everyone.
          2.The devil logo in everyones username.
          3.Fixed Optifine.
          
V1.0 Features-
          1.Custom Main menu.
          2.1.7 animation.
          3.eating animation.
Hi welcome to my client page, yes i am a single person devloping it.
Till now i have added custom main menu and made my own 1.7 animation(for bow and sword).
And the eating is a bit realistic(the position is in the center).

![Screenshot from 2021-09-28 20-27-53](https://user-images.githubusercontent.com/74668157/135113385-65366de3-df95-4e75-8bfb-c03860d3f84c.png)

# How to Install the client

1. Download the zip.
2. Put the DevilV1 folder in .minecraft/versions folder(if you dont know where it is, in windows it is in %appdata%)


# INFO
if you find any bugs or some un natural stuff in it please reoprt it to me.
My discord is Masked Alt?#7803
